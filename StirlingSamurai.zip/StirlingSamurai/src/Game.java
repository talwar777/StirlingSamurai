import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashMap;



import game2D.*;

// Student ID: 3142868


@SuppressWarnings("serial")


public class Game extends GameCore 
{
	//Game State
	enum GameState { START, PLAYING, PAUSED, GAMEOVER, VICTORY }
	GameState gameState = GameState.START;
    //Screens
    Image startScreen;
    Image gameOverScreen;
    Image pauseScreen; 
    Image victoryScreen;

	// Game Screen Constants
	static int screenWidth = 512;
	static int screenHeight = 384;
	boolean isFullscreen = false;  

	// Game constants
	float gravity = 0.001f;  
	float jumpPower = -0.5f; 
	float maxFallSpeed = 0.04f; 
    float	moveSpeed = 0.15f;
    boolean isJumping = false;
    boolean playerAlive = true;

    
    // Game state flags
    boolean moveRight = false;
    boolean moveLeft = false;
    boolean debug = true;	
    
    //Game player and enemy helth 
    int playerHealth = 7;
    int wolfHealth = 3;
    boolean wolfAlive = true;
    boolean isAttacking = false;
    long lastWolfAttackTime = 0;
    long lastPlayerAttackTime = 0;
    
    // this will check the health and if alive for all the wolfs 
    HashMap<Sprite, Integer> wolfHealthMap = new HashMap<>();
    HashMap<Sprite, Boolean> wolfAliveMap = new HashMap<>();


    // player resources
    Animation idle, walk, run, jump, attack, hurt, dead, block;
    
    // white wolf  
    Animation WWIdle, WWWalk, WWAttack, WWHurt, WWDead;

    // red wolf
    Animation RWIdle, RWWalk, RWAttack, RWHurt, RWDead;

    ArrayList<Sprite> wolves = new ArrayList<>(); // Store all wolves
    
    // Rock
    Animation rockAnimation;
    Sprite rock;
    
    //the level game starts in 
    int currentLevel = 1;
    
    //Background sound
    Sound bgMusic; 

    // Parallax background
    private Image bgFar, bgNear; //1
    private Image bgFar2, bgMiddle2, bgNear2; //2

    // 1 parallax position
    private float bgFarX = 0, bgNearX = 0;
    // 2 parallax position
    private float bgFar2X = 0, bgMiddle2X = 0, bgNear2X = 0;
    

    // heart 
    private Image heartImage;
    private ArrayList<Point> hearts = new ArrayList<>();

    // Coin 
    private Image coinImage;
    private ArrayList<Point> coins = new ArrayList<>();
    private int coinScore = 0;  // Total collected coins

    
    Sprite	player = null;
    //Birds
    ArrayList<Sprite> 	birds = new ArrayList<Sprite>();
    ArrayList<Tile>		collidedTiles = new ArrayList<Tile>();

    TileMap tmap = new TileMap();	// Our tile map, note that we load it in init()
    
    long total;


    /**
	 * The obligatory main method that creates
     * an instance of our class and starts it running
     * 
     * @param args	The list of parameters this program might use (ignored)
     */
//MAIN    
    public static void main(String[] args) {
        Game gct = new Game();
        gct.init();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        screenWidth = 1024; // Initial windowed size
        screenHeight = 768;

        gct.run(false, screenWidth, screenHeight);  // Start windowed
    }


//INIT    
    public void init()
    {         
        Sprite s;	// Temporary reference to a sprite

        // Load the tile map
        tmap.loadMap("maps", "map.txt");
        
        //start and end screens
        startScreen = loadImage("Background/StartScreen.png");
        gameOverScreen = loadImage("Background/GameOver.png");
        pauseScreen =  loadImage("Background/pause.png");
        victoryScreen = loadImage("Background/victory.png"); 
                
        setSize(screenWidth, screenHeight);
        setVisible(true);
        
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (gameState == GameState.START) {
                    currentLevel = 1;
                    initialiseGame(); 
                    gameState = GameState.PLAYING;
                } else if (gameState == GameState.GAMEOVER || gameState == GameState.VICTORY) {
                    currentLevel = 1;
                    initialiseGame();
                    gameState = GameState.PLAYING;
                } else if (gameState == GameState.PAUSED) {
                    gameState = GameState.PLAYING; // Resume the game
                }
            }
        });
        
        // Load background 1
        bgFar = Toolkit.getDefaultToolkit().getImage("Background/1.png"); 
        bgNear = Toolkit.getDefaultToolkit().getImage("Background/2.png");
        
        // Load Level 2
        bgFar2 = Toolkit.getDefaultToolkit().getImage("Background/far2.png");
        bgMiddle2 = Toolkit.getDefaultToolkit().getImage("Background/middle2.png");
        bgNear2 = Toolkit.getDefaultToolkit().getImage("Background/near2.png");
        
        // Load Player
        idle = new Animation();
        idle.loadAnimationFromSheet("images/Idle.png", 6, 1, 60);
        
        walk = new Animation();
        walk.loadAnimationFromSheet("images/Walk.png", 9, 1, 90);
        
        run = new Animation();
        run.loadAnimationFromSheet("images/Run.png", 8, 1, 80);

        jump = new Animation();
        jump.loadAnimationFromSheet("images/Jump.png", 9, 1, 120);
        jump.setLoop(false); // jump will not loop

        attack = new Animation();
        attack.loadAnimationFromSheet("images/Attack.png", 4, 1, 90);
        attack.setLoop(false);

        hurt = new Animation();
        hurt.loadAnimationFromSheet("images/Hurt.png", 3, 1, 100);

        dead = new Animation();
        dead.loadAnimationFromSheet("images/Dead.png", 6, 1, 400);

        block = new Animation();
        block.loadAnimationFromSheet("images/Protection.png", 2, 1, 100);
        block.setLoop(false);

        // player idle by default 
        player = new Sprite(idle);
        player.show(); 
        
        // Load enemy Level 1
        WWIdle = new Animation();
        WWIdle.loadAnimationFromSheet("Enemy/W_Idle.png", 8, 1, 100);

        WWWalk = new Animation();
        WWWalk.loadAnimationFromSheet("Enemy/W_Walk.png", 11, 1, 80);

        WWAttack = new Animation();
        WWAttack.loadAnimationFromSheet("Enemy/W_Attack.png", 6, 1, 100);

        WWHurt = new Animation();
        WWHurt.loadAnimationFromSheet("Enemy/W_Hurt.png", 2, 1, 100);

        WWDead = new Animation();
        WWDead.loadAnimationFromSheet("Enemy/W_Dead.png", 2, 1, 100);

        // Load Red Wolf Level 2
        RWIdle = new Animation();
        RWIdle.loadAnimationFromSheet("Enemy/R_Idle.png", 8, 1, 100);

        RWWalk = new Animation();
        RWWalk.loadAnimationFromSheet("Enemy/R_Run.png", 9, 1, 80);

        RWAttack = new Animation();
        RWAttack.loadAnimationFromSheet("Enemy/R_Attack.png", 5, 1, 100);

        RWHurt = new Animation();
        RWHurt.loadAnimationFromSheet("Enemy/R_Hurt.png", 2, 1, 100);

        RWDead = new Animation();
        RWDead.loadAnimationFromSheet("Enemy/R_Dead.png", 2, 1, 100);

        
        // Load Birds animation
        Animation ca = new Animation();
        ca.loadAnimationFromSheet("images/birds.png", 4, 1, 280);
        
        // fire tile animation 
        Animation fireAnimation = new Animation();
        fireAnimation.loadAnimationFromSheet("images/fire1.png", 8, 1, 100);
        tmap.setFireAnimation(fireAnimation);

        
        // Create 3 birds at random positions off the screen
        for (int c=0; c<4; c++)
        {
        	Sprite bird = new Sprite(ca);
        	bird.setX(screenWidth + (int)(Math.random()*200.0f));
        	bird.setY(30 + (int)(Math.random()*150.0f));
        	bird.setVelocityX(-0.05f);
        	bird.show();
        	birds.add(bird);
        }
                
        // find Heart h inmap 
        heartImage = Toolkit.getDefaultToolkit().getImage("images/heart.png");        
        for (int y = 0; y < tmap.getMapHeight(); y++)
        {
            for (int x = 0; x < tmap.getMapWidth(); x++) 
            {
                char tileChar = tmap.getTileChar(x, y);
                if (tileChar == 'h') 
                {
                    int heartX = x * tmap.getTileWidth();
                    int heartY = y * tmap.getTileHeight();
                    hearts.add(new Point(heartX, heartY));
                }
            }
        }
                
        // Find coins g 
        coinImage = Toolkit.getDefaultToolkit().getImage("images/g_coin.png");
        for (int y = 0; y < tmap.getMapHeight(); y++) 
        {
            for (int x = 0; x < tmap.getMapWidth(); x++) 
            {
                char tileChar = tmap.getTileChar(x, y);
                if (tileChar == 'g') 
                {
                    int coinX = x * tmap.getTileWidth();
                    int coinY = y * tmap.getTileHeight();
                    coins.add(new Point(coinX, coinY));
                }
            }
        }
        
        //Rock Animation
        rockAnimation = new Animation();
        rockAnimation.loadAnimationFromSheet("images/rock.png", 4, 1, 100);

        rock = new Sprite(rockAnimation);
        // Set rock starting X position differently based on level
        int rockStartX = (currentLevel == 1) ? 800 : 1500; // Change position as needed per level

        rock.setX(rockStartX); // Start position based on level
        
        // Place rock on ground
        int rockTileX = (int) (rock.getX() / tmap.getTileWidth());
        int rockTileY = 0;

        // Start checking from the bottom (ground level) up
        for (int y = tmap.getMapHeight() - 1; y >= 0; y--) {
            char tile = tmap.getTileChar(rockTileX, y);
            if (tile == 'x' || tile == 'y' || tile == 'z') {
                rockTileY = y;
                break;
            }
        }

        // rock on top of ground
        rock.setY((rockTileY * tmap.getTileHeight()) - rock.getHeight());
        rock.setVelocityX(-0.05f); // Moves left
        rock.show();
        
        Sprite wolf;

        if (currentLevel == 1) {
            wolf = new Sprite(WWIdle);
            wolf.setAnimation(WWWalk);
        } else { // currentLevel == 2
            wolf = new Sprite(RWIdle);
            wolf.setAnimation(RWWalk);
        }

        int wolfX = (int) (player.getX() + 450);
        int tileX = wolfX / tmap.getTileWidth();
        int tileY = 0;

        for (int y = 0; y < tmap.getMapHeight(); y++) {
            char c = tmap.getTileChar(tileX, y);
            if (c == 'x' || c == 'y' || c == 'z') {
                tileY = y;
                break;
            }
        }

        int wolfY = tileY * tmap.getTileHeight() - wolf.getHeight();
        wolf.setPosition(wolfX, wolfY);
        wolf.setVelocityX(-0.02f);
        wolf.setScale(-1, 1);
        wolf.show();
        wolves.add(wolf);

        
        System.out.println(tmap);
        
        //Start Background Music
        bgMusic = new Sound("sounds/arabNight.mid");
        bgMusic.start();
        
        initialiseGame();
    }

//initialiseGame
    //this is how the game will Reset after game over 
    public void initialiseGame() {
        total = 0;
        playerHealth = 7;
        wolfHealth = 3;
        wolfAlive = true;        

        // Clear previous data
        wolves.clear(); 
        coins.clear();
        hearts.clear();
        
        // Load map according current level
        if (currentLevel == 1) {
            tmap.loadMap("maps", "map.txt");
        } else {
            tmap.loadMap("maps", "map_2.txt");
        }
        
        //Reset player positio
        player.setPosition(100, 300);
        player.setVelocity(0, 0);
        player.setAnimation(idle);
        playerAlive = true;
        player.show();
        
        // Reset rock position based on current level
        int rockStartX = (currentLevel == 1) ? 800 : 1500; // Change as needed per level
        rock.setX(rockStartX);
        
        // Reset rock velocity explicitly
        rock.setVelocityX(-0.05f);
        rock.show();

        // Place rock correctly on ground
        int rockTileX = (int) (rock.getX() / tmap.getTileWidth());
        int rockTileY = 0;
        for (int y = tmap.getMapHeight() - 1; y >= 0; y--) {
            char tile = tmap.getTileChar(rockTileX, y);
            if (tile == 'x' || tile == 'y' || tile == 'z') {
                rockTileY = y;
                break;
            }
        }
        rock.setY((rockTileY * tmap.getTileHeight()) - rock.getHeight());
        
        // Spawn wolves based on the level
        int numberOfWolves = (currentLevel == 1) ? 2 : 3;

        for (int i = 0; i < numberOfWolves; i++) {
            Sprite wolf = (currentLevel == 1) ? new Sprite(WWIdle) : new Sprite(RWIdle);
            wolf.setAnimation(currentLevel == 1 ? WWWalk : RWWalk);

            int wolfX = (int) (player.getX() + 450 + (i * 300)); // the space between each wolf is set by i* x
            int tileX = wolfX / tmap.getTileWidth();
            int tileY = -1;

            for (int y = 0; y < tmap.getMapHeight(); y++) {
                char c = tmap.getTileChar(tileX, y);
                if (c == 'x' || c == 'y' || c == 'z') {
                    tileY = y;
                    break;
                }
            }


            int wolfY = ((tileY - 1) * tmap.getTileHeight()) - wolf.getHeight();
            if (wolfY < 0) wolfY = 0;
            

            wolf.setPosition(wolfX, wolfY);
            wolf.setVelocityX(-0.02f);
            wolf.setScale(-1, 1);
            wolf.show();
            wolves.add(wolf);
            
            // Using Hash Map 
            wolfHealthMap.put(wolf, 3); // 3 HP for each wolf
            wolfAliveMap.put(wolf, true); 
            
        }
        
        // reload heart
        for (int y = 0; y < tmap.getMapHeight(); y++) {
            for (int x = 0; x < tmap.getMapWidth(); x++) {
                char tileChar = tmap.getTileChar(x, y);
                if (tileChar == 'h') {
                    int heartX = x * tmap.getTileWidth();
                    int heartY = y * tmap.getTileHeight();
                    hearts.add(new Point(heartX, heartY));
                }
            }
        }
        
        // Reset BG
        if (currentLevel == 1) {
            bgFarX = 0;
            bgNearX = 0;
        }
        else if (currentLevel == 2) {
            bgFar2X = 0;
            bgMiddle2X = 0;
            bgNear2X = 0;
        }
        
        // Clear previous bird data and spawn new birds
        birds.clear();
        Animation birdAnimation = new Animation();
        birdAnimation.loadAnimationFromSheet("images/birds.png", 4, 1, 280);

        // Create 3 birds with random positions for Level 2
        for (int c = 0; c < 4; c++) {
            Sprite bird = new Sprite(birdAnimation);
            bird.setX(screenWidth + (int) (Math.random() * 200.0f)); // Start off-screen
            bird.setY(30 + (int) (Math.random() * 150.0f)); // Random Y position
            bird.setVelocityX(-0.05f);
            bird.show();
            birds.add(bird);
        }
        

        if (gameState == GameState.GAMEOVER) {
            coinScore = 0; // Only reset on game over
        }
        
        //Reload coins
        for (int y = 0; y < tmap.getMapHeight(); y++) {
            for (int x = 0; x < tmap.getMapWidth(); x++) {
                char tileChar = tmap.getTileChar(x, y);
                if (tileChar == 'g') {
                    int coinX = x * tmap.getTileWidth();
                    int coinY = y * tmap.getTileHeight();
                    coins.add(new Point(coinX, coinY));
                }
            }
        }
    }


    /**
     * Draw the current state of the game. Note the sample use of
     * debugging output that is drawn directly to the game screen.
     */
    public void toggleFullscreen() {
        isFullscreen = !isFullscreen;

        GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();

        // Dispose the current frame before applying changes
        dispose();

        if (isFullscreen) {
            setUndecorated(true);
            gd.setFullScreenWindow(this);
            screenWidth = gd.getDisplayMode().getWidth();
            screenHeight = gd.getDisplayMode().getHeight();
            
        }
        else {
            setUndecorated(false);
            gd.setFullScreenWindow(null);
            screenWidth = 1024;
            screenHeight = 768;
        }

        setResizable(!isFullscreen);
        setVisible(true);
        revalidate();
    }


//DRAW    
    public void draw(Graphics2D g)
    {       	
    	// Start Screen
    	if (gameState == GameState.START) {
    	    g.drawImage(startScreen, 0, 0, screenWidth, screenHeight, null);

    	    // Draw Game Title: Stirling Samurai
    	    g.setColor(Color.WHITE);
    	    g.setFont(new Font("Arial", Font.BOLD, 48)); // Larger font for title
    	    String gameTitle = "Stirling Samurai";
    	    FontMetrics fmTitle = g.getFontMetrics();
    	    int titleX = (screenWidth - fmTitle.stringWidth(gameTitle)) / 2;
    	    int titleY = screenHeight / 3; // Position at 1/3 height for better visibility
    	    g.drawString(gameTitle, titleX, titleY);

    	    // Draw Start Message
    	    g.setFont(new Font("Arial", Font.BOLD, 24)); // Slightly larger font for the start message
    	    String startMessage = "CLICK ANYWHERE TO START";
    	    FontMetrics fmMessage = g.getFontMetrics();
    	    int startX = (screenWidth - fmMessage.stringWidth(startMessage)) / 2;
    	    int startY = titleY + 80; // Position below the title
    	    g.drawString(startMessage, startX, startY);

    	    // Controls Info
    	    g.setFont(new Font("Arial", Font.BOLD, 16));
    	    String[] controls = {
    	        "CONTROLS:",
    	        "UP Arrow     = Jump",
    	        "RIGHT Arrow  = Move Right",
    	        "LEFT Arrow   = Move Left",
    	        "A            = Attack",
    	        "D            = Block",
    	        "P            = Pause",
    	        "F            = Toggle Fullscreen or Normal",
    	        "ESC          = Exit"
    	    };
    	    int controlStartY = startY + 50;
    	    for (String control : controls) {
    	        int controlX = (screenWidth - fmMessage.stringWidth(control)) / 2;
    	        g.drawString(control, controlX, controlStartY);
    	        controlStartY += 20;
    	    }
    	    return;
    	}

    	


    	    // game over screen
    	    if (gameState == GameState.GAMEOVER) {
    	    	g.drawImage(gameOverScreen, 0, 0, screenWidth, screenHeight, null);
                
    	    	g.setColor(Color.WHITE);
	    	    g.setFont(new Font("Arial", Font.BOLD, 18));
	    	    String startMessage = "CLICK ANYWHERE TO RESTART";
	    	    FontMetrics fm = g.getFontMetrics();
	    	    int startX = (screenWidth - fm.stringWidth(startMessage)) / 2;
	    	    int startY = screenHeight - 50	;
	    	    g.drawString(startMessage, startX, startY);
                

    	        return;
    	    }
    	    // Pause Screen
    	    if (gameState == GameState.PAUSED) {
    	        g.drawImage(pauseScreen, 0, 0, screenWidth, screenHeight, null);
    	        
    	        g.setColor(Color.WHITE);
    	        g.setFont(new Font("Arial", Font.BOLD, 32));
    	        String pauseMessage = "PAUSED";
    	        FontMetrics fm = g.getFontMetrics();
    	        int pauseX = (screenWidth - fm.stringWidth(pauseMessage)) / 2;
    	        int pauseY = screenHeight / 2;
    	        g.drawString(pauseMessage, pauseX, pauseY);

    	        g.setFont(new Font("Arial", Font.BOLD, 16));
    	        g.setColor(Color.RED);
    	        String resumeMessage = "CLICK ANYWHERE TO RESUME";    	        
    	        int resumeX = (screenWidth - fm.stringWidth(resumeMessage)) / 2;
    	        int resumeY = 50; // Positioned 50 pixels from the top
    	        g.drawString(resumeMessage, resumeX, resumeY);

    	        return;
    	    }

    	    // Victory Screen
    	    if (gameState == GameState.VICTORY) {
    	        g.drawImage(victoryScreen, 0, 0, screenWidth, screenHeight, null);
    	        g.setColor(Color.WHITE);
    	        g.setFont(new Font("Arial", Font.BOLD, 32));
    	        String victoryMessage = "CONGRATULATIONS! YOU WON!";
    	        FontMetrics fm = g.getFontMetrics();
    	        int victoryX = (screenWidth - fm.stringWidth(victoryMessage)) / 2;
    	        int victoryY = screenHeight / 2 - 20;
    	        g.drawString(victoryMessage, victoryX, victoryY);

    	        String restartMessage = "CLICK ANYWHERE TO RESTART";
    	        int restartX = (screenWidth - fm.stringWidth(restartMessage)) / 2;
    	        g.drawString(restartMessage, restartX, victoryY + 40);
    	        //coin Score
    	        String coinMessage = "Coins Collected: " + coinScore;
    	        int coinX = (screenWidth - fm.stringWidth(coinMessage)) / 2;
    	        g.drawString(coinMessage, coinX, victoryY + 80); // Adjust for better visibility

    	        return;
    	    }

                    
    	    //Backgrounds
        if (currentLevel == 1) {
            g.drawImage(bgFar, (int) bgFarX, 0, screenWidth, screenHeight, null);
            g.drawImage(bgFar, (int) bgFarX + screenWidth, 0, screenWidth, screenHeight, null);
            g.drawImage(bgNear, (int) bgNearX, 0, screenWidth, screenHeight, null);
            g.drawImage(bgNear, (int) bgNearX + screenWidth, 0, screenWidth, screenHeight, null);
        }
        else if (currentLevel == 2) {
            g.drawImage(bgFar2, (int) bgFar2X, 0, screenWidth, screenHeight, null);
            g.drawImage(bgFar2, (int) bgFar2X + screenWidth, 0, screenWidth, screenHeight, null);
            g.drawImage(bgMiddle2, (int) bgMiddle2X, 0, screenWidth, screenHeight, null);
            g.drawImage(bgMiddle2, (int) bgMiddle2X + screenWidth, 0, screenWidth, screenHeight, null);
            g.drawImage(bgNear2, (int) bgNear2X, 0, screenWidth, screenHeight, null);
            g.drawImage(bgNear2, (int) bgNear2X + screenWidth, 0, screenWidth, screenHeight, null);
        }


    	int xo = -(int)player.getX() + 200;  // camera X offset
    	int yo = 0;  

        
        // Apply offsets to sprites then draw them
        for (Sprite bird: birds)
        {
        	bird.setOffsets(xo,yo);
        	bird.draw(g);
        }

        // Apply offsets to tile map and draw
        tmap.draw(g,xo,yo); 

        // Apply offsets to player and draw 
        player.setOffsets(xo, yo);
        player.draw(g);
        
        // Apply offsets to wolves and draw
        for (Sprite wolf : wolves) 
        {
            wolf.setOffsets(xo, yo);
            wolf.draw(g);
        }
        
        // draw the rock
        rock.setOffsets(xo, yo);
        rock.draw(g);                
        
        // display heats for health
        int heartDisplayX = getWidth() - (playerHealth * 35) - 20; // Adjust position based on the number of hearts
        for (int i = 0; i < playerHealth; i++) {
            g.drawImage(heartImage, heartDisplayX + (i * 35), 40, 30, 30, null);
        }        

        // Draw Hearts from the Map
        for (Point heart : hearts) {
            int heartX = heart.x + xo;
            int heartY = heart.y + yo;
            g.drawImage(heartImage, heartX, heartY, 20, 20, null);
        }

        // Draw Coins from the map
        for (int i = 0; i < coins.size(); i++) 
        	{  
            Point coin = coins.get(i);
            int coinX = coin.x + xo;
            int coinY = coin.y + yo;

            // Only draw if the tile 'g'
            int tileX = coin.x / tmap.getTileWidth();
            int tileY = coin.y / tmap.getTileHeight();
            
            if (tmap.getTileChar(tileX, tileY) == 'g')
            {  
                g.drawImage(coinImage, coinX, coinY, 20, 20, null);
            }
        }


        // Display Coin Score
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.setColor(Color.YELLOW);
        g.drawString("Coins: " + coinScore, 20, 50);

        
        if (debug)
        {

        	// When in debug mode, you could draw borders around objects
            // and write messages to the screen with useful information.
            // Try to avoid printing to the console since it will produce 
            // a lot of output and slow down your game.
            tmap.drawBorder(g, xo, yo, Color.white);

            g.setColor(Color.red);
        	player.drawBoundingBox(g);
        
        	g.drawString(String.format("Player: %.0f,%.0f", player.getX(),player.getY()),
        								getWidth() - 100, 70);
        	
        	drawCollidedTiles(g, tmap, xo, yo);
        	g.setColor(Color.RED);
        	g.drawString("Player HP: " + playerHealth, 20, 70);
        	if (wolfAlive) g.drawString("Wolf HP: " + wolfHealth, 20, 90);

        }

    }

    public void drawCollidedTiles(Graphics2D g, TileMap map, int xOffset, int yOffset)
    {
		if (collidedTiles.size() > 0)
		{	
			int tileWidth = map.getTileWidth();
			int tileHeight = map.getTileHeight();
			
			g.setColor(Color.blue);
			for (Tile t : collidedTiles)
			{
				g.drawRect(t.getXC()+xOffset, t.getYC()+yOffset, tileWidth, tileHeight);
			}
		}
    }
	

//UPDATE    
    public void update(long elapsed)
    {
        if (gameState == GameState.PAUSED || gameState == GameState.START || gameState == GameState.GAMEOVER || gameState == GameState.VICTORY) {
            return;
        }
    	if (currentLevel == 1) {
    	    bgFarX -= player.getVelocityX() * 3.5;
    	    bgNearX -= player.getVelocityX() * 6.0;

    	    if (bgFarX <= -getWidth()) bgFarX = 0;
    	    if (bgNearX <= -getWidth()) bgNearX = 0;
    	}
    	else if (currentLevel == 2) {
    	    bgFar2X -= player.getVelocityX() * 2.5;
    	    bgMiddle2X -= player.getVelocityX() * 4.5;
    	    bgNear2X -= player.getVelocityX() * 7.0;

    	    if (bgFar2X <= -getWidth()) bgFar2X = 0;
    	    if (bgMiddle2X <= -getWidth()) bgMiddle2X = 0;
    	    if (bgNear2X <= -getWidth()) bgNear2X = 0;
    	}


    	// apply gravity
    	float newVelocityY = player.getVelocityY() + (gravity * elapsed);
    	player.setVelocityY(Math.min(newVelocityY, maxFallSpeed));

    	if (playerAlive && !isAttacking) {
    	if (playerAlive) {
	    	if (isOnGround(player)) {    	     
	    	    isJumping = false; 
	    	}
	    	else {
	    		player.setAnimation(idle);
	    	}
	
	    	
	       	player.setAnimationSpeed(1.0f);
	       	
	       	if (moveRight) 
	       	{
	       		player.setVelocityX(moveSpeed);
	       	    if (isOnGround(player)) player.setAnimation(run);
	       	}
	       	else if (moveLeft) 
	       	{
	       		player.setVelocityX(-moveSpeed);
	       	    if (isOnGround(player)) player.setAnimation(walk);
	       	}
	       	else
	       	{
	       		player.setVelocityX(0);
	       	}
    	}
    	else {
    	    // Player is dead: explicitly force death animation
    	    if (player.getAnimation() != dead) {
    	    	dead.start();
    	        player.setAnimation(dead);
    	    }
    	    player.setVelocity(0, 0);
    	}
    	}
       		
    	// Check for heart collection
    	for (int i = hearts.size() - 1; i >= 0; i--) {
    	    Point heart = hearts.get(i);
    	    Rectangle heartRect = new Rectangle(heart.x, heart.y, 20, 20);
    	    Rectangle playerRect = new Rectangle((int)player.getX(), (int)player.getY(), player.getWidth(), player.getHeight());

    	    if (playerRect.intersects(heartRect)) {
    	        hearts.remove(i);  // Remove heart from map
    	        int tileX = heart.x / tmap.getTileWidth();
    	        int tileY = heart.y / tmap.getTileHeight();
    	        tmap.setTileChar('.', tileX, tileY); // Clear the heart tile
    	        if (playerHealth < 7) {
    	            playerHealth++; // Increase health by 1
    	        }
    	        //new Sound("sounds/heart_collect.wav").start();
    	    }
    	}

       	// Check for coin collection
       	for (int i = coins.size() - 1; i >= 0; i--)// Loop backwards to prevent index shifting issues 
       	{  
       	    Point coin = coins.get(i);

       	    // Define hitboxes
       	    Rectangle coinRect = new Rectangle(coin.x, coin.y, 20, 20); 
       	    Rectangle playerRect = new Rectangle((int)player.getX(), (int)player.getY(), player.getWidth(), player.getHeight());

       	    if (playerRect.intersects(coinRect)) 
       	    {
       	        // Remove from coins list
       	        coins.remove(i);  
       	        
       	        // Clear the coin from the tile map
       	        int tileX = coin.x / tmap.getTileWidth();
       	        int tileY = coin.y / tmap.getTileHeight();
       	        tmap.setTileChar('.', tileX, tileY);  // Set tile to empty

       	        // Increase score
       	        coinScore++;  

       	        // Play sound effect
       	        new Sound("sounds/coin_recieved.wav").start();
       	    }
       	}
       	// Update rock
       	rock.update(elapsed);

       	//if the rock goes off screen reset it
       	if (rock.getX() < -rock.getWidth()) {
       	    rock.setX(screenWidth);
       	}

       	// rock collision with the player
       	if (boundingBoxCollision(player, rock)) {
       	    playerAlive = false;
       	    new Sound("sounds/death.wav").start();        	    
       	    player.setAnimation(dead);
       	    player.setVelocity(0, 0);
       	    player.getAnimation().start();
       	    rock.setVelocityX(0);
       	    gameState = GameState.GAMEOVER;
       	    // Stop the background music
            if (gameState == GameState.GAMEOVER && bgMusic != null) {
                bgMusic.stop();
            }
       	    player.setX(player.getX() - 50);
       	}
       	// Player stepped on fire 
       	if (tmap.isPlayerOnFireTile(player)) {
       		playerAlive = false;
       	    player.setAnimation(dead); // Play the death animation
       	    player.setVelocity(0, 0);
       	    rock.setVelocityX(0);
       	    new Sound("sounds/death.wav").start();
       	    gameState = GameState.GAMEOVER;  
       	    // 	Stop the background music
            if (gameState == GameState.GAMEOVER && bgMusic != null) {
                bgMusic.stop();
            }
       	}

       	// Check if player reached the end of the level
       	if (player.getX() > tmap.getPixelWidth() - 50) { 
       	    if (currentLevel == 1) {
       	        currentLevel = 2;
       	        initialiseGame(); // Load level 2
       	    } else if (currentLevel == 2) {
       	        gameState = GameState.VICTORY; //Won Game 
       	        player.setVelocity(0, 0);
       	        player.setAnimation(idle);
       	    }
       	}


        //update Bird        
       	for (Sprite bird: birds)
       		bird.update(elapsed);
       	
        // update player
        player.update(elapsed);

        // Update wolf
        updateWolves(elapsed);


       
        // Then check for any collisions that may have occurred
        handleScreenEdge(player, tmap, elapsed);
        checkTileCollision(player, tmap);
    }
    
    
    /**
     * Checks and handles collisions with the edge of the screen. You should generally
     * use tile map collisions to prevent the player leaving the game area. This method
     * is only included as a temporary measure until you have properly developed your
     * tile maps.
     * 
     * @param s			The Sprite to check collisions for
     * @param tmap		The tile map to check 
     * @param elapsed	How much time has gone by since the last call
     */
    public void handleScreenEdge(Sprite s, TileMap tmap, long elapsed)
    {
    	// This method just checks if the sprite has gone off the bottom screen.
    	// Ideally you should use tile collision instead of this approach
    	
    	float difference = s.getY() + s.getHeight() - tmap.getPixelHeight();
        if (difference > 0)
        {
        	// Put the player back on the map according to how far over they were
        	s.setY(tmap.getPixelHeight() - s.getHeight() - (int)(difference)); 
        	
        	// and make them bounce
        	s.setVelocityY(-s.getVelocityY()*0.75f);
        }
    }
    
    
     
    /**
     * Override of the keyPressed event defined in GameCore to catch our
     * own events
     * 
     *  @param e The event that has been generated
     */
    public void keyPressed(KeyEvent e) 
    { 
    	int key = e.getKeyCode();
    	
		switch (key)
		{
		
        case KeyEvent.VK_F:
            toggleFullscreen();
            break;
            
			case KeyEvent.VK_UP:
			    if (isOnGround(player) && !isJumping)//this will check velocity
			    { 
			        player.setVelocityY(jumpPower);
			        
			        jump.start(); //resets the animation to frame 0
			        player.setAnimation(jump); // Only trigger once
			        isJumping = true;
			        new Sound("sounds/jumping.wav").start(); // jump sound
			    }
			    break;
			    
			case KeyEvent.VK_RIGHT:
			    moveRight = true;
			    player.setVelocityX(moveSpeed);
			    if (isOnGround(player)) player.setAnimation(run); // Run animation only if on ground
			    break;

			case KeyEvent.VK_LEFT:
			    moveLeft = true;
			    player.setVelocityX(-moveSpeed);
			    if (isOnGround(player)) 
			    {
			        player.setAnimation(walk);			        
			    }
			    break;


			//Attack 
			case KeyEvent.VK_A:
			    if (!isAttacking && playerAlive) {
			        isAttacking = true;
			        attack.start();
			        player.setAnimation(attack);
			        new Sound("sounds/sword.wav").start();

			        long now = System.currentTimeMillis();
			        if (now - lastPlayerAttackTime > 500) {
			            for (Sprite wolf : wolves) {
			                if (wolfAliveMap.get(wolf) && boundingBoxCollision(player, wolf)) {
			                    int currentHealth = wolfHealthMap.get(wolf) - 1;
			                    wolfHealthMap.put(wolf, currentHealth);
			                    new Sound("sounds/hurt.wav").start();
			                    System.out.println("Wolf hit! Remaining Health: " + currentHealth);

			                    if (currentHealth <= 0) {
			                        System.out.println("Wolf died!");
			                        wolfAliveMap.put(wolf, false);

			                        if (currentLevel == 1)
			                            wolf.setAnimation(WWDead);
			                        else
			                            wolf.setAnimation(RWDead);

			                        wolf.setVelocityX(0);

			                        // wolf on the ground when dead
			                        int tileX = (int) ((wolf.getX() + wolf.getWidth() / 2) / tmap.getTileWidth());
			                        int tileY = 0;

			                        for (int y = tmap.getMapHeight() - 1; y >= 0; y--) {
			                            char tileChar = tmap.getTileChar(tileX, y);
			                            if (tileChar == 'x' || tileChar == 'y' || tileChar == 'z') {
			                                tileY = y;
			                                break;
			                            }
			                        }

			                        wolf.setY((tileY * tmap.getTileHeight()) - wolf.getHeight());
			                    
			                        new Thread(() -> {
			                            try {
			                                Thread.sleep(3000);
			                                wolf.hide();
			                                wolves.remove(wolf);
			                            } catch (InterruptedException ex) {
			                                ex.printStackTrace();
			                            }
			                        }).start();
			                    }
			                    break;
			                }
			            }
			            lastPlayerAttackTime = now;
			        }

			        // Reset the attacking state after animation completes (approx 360 ms)
			        new Thread(() -> {
			            try {
			                Thread.sleep(360); // duration of your attack animation (4 frames * 90 ms)
			            } catch (InterruptedException ex) {}
			            isAttacking = false;
			            player.setAnimation(idle);
			        }).start();
			    }
			    break;

			case KeyEvent.VK_D:
			    player.setAnimation(block);
			    new Thread(() -> { // Reset to idle after blocking
			        try { Thread.sleep(700); } catch (InterruptedException ex) {}
			        player.setAnimation(idle);
			    }).start();
			    break;
			    			    
			//paus only on playing state 
			case KeyEvent.VK_P:
			    if (gameState == GameState.PLAYING) {
			        gameState = GameState.PAUSED;
			    }
			    break;
			    
			case KeyEvent.VK_ESCAPE:
	            stop();
	            break;

			case KeyEvent.VK_B 		: debug = !debug; break; // Flip the debug state
			default :  break;
		}
    
    }

    /** Use the sample code in the lecture notes to properly detect
     * a bounding box collision between sprites s1 and s2.
     * 
     * @return	true if a collision may have occurred, false if it has not.
     */
    public boolean boundingBoxCollision(Sprite s1, Sprite s2)
    {
        float s1x = s1.getX();
        float s1y = s1.getY();
        float s1w = s1.getWidth();
        float s1h = s1.getHeight();

        float s2x = s2.getX();
        float s2y = s2.getY();
        float s2w = s2.getWidth();
        float s2h = s2.getHeight();

        return ((s1x + s1w) >= s2x) && (s1x <= s2x + s2w) &&
               ((s1y + s1h) >= s2y) && (s1y <= s2y + s2h);
    }

    
    /**
     * @param s			The Sprite to check collisions for
     * @param tmap		The tile map to check 
     */
    public void checkTileCollision(Sprite s, TileMap tmap)
    {
        // Clear the list of tiles the player might be touching
        collidedTiles.clear();

        // player poition
        float sx = s.getX();
        float sy = s.getY();

        // size tile From map
        float tileWidth = tmap.getTileWidth();
        float tileHeight = tmap.getTileHeight();

        // Work out which tile the player's different parts are touching
        int xtileLeft   = (int)(sx / tileWidth);                        // Tile on the left side
        int xtileRight  = (int)((sx + s.getWidth()) / tileWidth);       // Tile on the right side
        int ytileBottom = (int)((sy + s.getHeight()) / tileHeight);     // Tile below the player
        int ytileMiddle = (int)((sy + s.getHeight()/2) / tileHeight);   // Tile in the middle

        // ground collision
        Tile bottomTile = tmap.getTile(xtileLeft, ytileBottom);
        if (bottomTile != null && bottomTile.getCharacter() != '.') 
        {
            // Place player on top of the tile
            float tileTopY = ytileBottom * tileHeight;
            s.setY(tileTopY - s.getHeight());

            // Ssetting velocity for player 
            s.setVelocityY(0);

            // Keep a record of the tile we hit
            collidedTiles.add(bottomTile);
        }

        // left side
        Tile leftTile = tmap.getTile(xtileLeft, ytileMiddle);
        if (leftTile != null && leftTile.getCharacter() != '.') 
        {
            // Push player to the right so they don't go into the wall
            float tileRightX = (xtileLeft + 1) * tileWidth;
            s.setX(tileRightX);

            // Stop moving sideways
            s.setVelocityX(0);

            collidedTiles.add(leftTile);
        }

        // right side
        Tile rightTile = tmap.getTile(xtileRight, ytileMiddle);
        if (rightTile != null && rightTile.getCharacter() != '.') 
        {
            // Push player to the left so they don't go into the wall
            float tileLeftX = xtileRight * tileWidth;
            s.setX(tileLeftX - s.getWidth());

            // Stop moving sideways
            s.setVelocityX(0);

            collidedTiles.add(rightTile);
        }
    }




	public void keyReleased(KeyEvent e) { 

		int key = e.getKeyCode();

		switch (key)
		{
		case KeyEvent.VK_ESCAPE:
            stop();
            break;

			case KeyEvent.VK_UP:
			    break;
			case KeyEvent.VK_RIGHT:
			    moveRight = false;
			    player.setVelocityX(0);
			    player.setAnimation(idle);
			    break;
			case KeyEvent.VK_LEFT:
			    moveLeft = false;
			    player.setVelocityX(0);
			    player.setAnimation(idle);
			    break;


			default :  break;
		}
	}
	
	//Checks if the player is on the ground by detecting collision with tiles below.
	public boolean isOnGround(Sprite s) {
	    int tileXLeft = (int) (s.getX() / tmap.getTileWidth());
	    int tileXRight = (int) ((s.getX() + s.getWidth() - 1) / tmap.getTileWidth());
	    int tileYBelow = (int) ((s.getY() + s.getHeight() + 1) / tmap.getTileHeight());

	    Tile leftTile = tmap.getTile(tileXLeft, tileYBelow);
	    Tile rightTile = tmap.getTile(tileXRight, tileYBelow);

	    char leftChar = (leftTile != null) ? leftTile.getCharacter() : '.';
	    char rightChar = (rightTile != null) ? rightTile.getCharacter() : '.';

	    boolean isSolid = (leftChar == 'x' || leftChar == 'y' || leftChar == 'z') ||
	                      (rightChar == 'x' || rightChar == 'y' || rightChar == 'z');
	    

	    return isSolid;
	}

	
	/**
	 * Moves wolves based on proximity to the player.
	 * Wolves will stay idle until the player gets within a detection range.
	 */
	public void updateWolves(long elapsed) {
	    int detectionRange = 300; // Wolves detect player within 300 pixels

	    for (Sprite wolf : wolves) {
	        boolean isWolfAlive = wolfAliveMap.get(wolf);
	        if (!isWolfAlive) continue; // Skip if wolf dead

	        // if the player is within detection range
	        float distanceToPlayer = Math.abs(player.getX() - wolf.getX());

	        // Idle state
	        if (distanceToPlayer > detectionRange) {
	            if (currentLevel == 1) {
	                wolf.setAnimation(WWIdle);
	            } else {
	                wolf.setAnimation(RWIdle);
	            }
	            wolf.setVelocityX(0);
	            
	            // Ensure the wolf is on the ground
	            int tileX = (int) ((wolf.getX() + wolf.getWidth() / 2) / tmap.getTileWidth());
	            int tileY = 0;

	            for (int y = tmap.getMapHeight() - 1; y >= 0; y--) {
	                char tileChar = tmap.getTileChar(tileX, y);
	                if (tileChar == 'x' || tileChar == 'y' || tileChar == 'z') {
	                    tileY = y;
	                    break;
	                }
	            }

	            wolf.setY((tileY * tmap.getTileHeight()) - wolf.getHeight());
	            continue;
	        }


	        // Gravity for wolf
	        if (!isOnGround(wolf)) {
	            float newVY = wolf.getVelocityY() + (gravity * elapsed);
	            wolf.setVelocityY(Math.min(newVY, maxFallSpeed));
	        } else {
	            wolf.setVelocityY(0);
	        }
	        wolf.setVelocityX(-0.025f);
	        float nextX = wolf.getX() + wolf.getVelocityX() * elapsed;
	        int nextTileX = (int)((nextX + wolf.getWidth() / 2) / tmap.getTileWidth());
	        int nextTileY = (int)((wolf.getY() + wolf.getHeight() + 1) / tmap.getTileHeight());
	        char tileBelow = tmap.getTileChar(nextTileX, nextTileY);

	        // If no ground ahead, turn around
	        if (tileBelow != 'x' && tileBelow != 'y' && tileBelow != 'z') {
	            wolf.setVelocityX(-wolf.getVelocityX());
	            wolf.setScale(wolf.getVelocityX() > 0 ? -1 : 1, 1); // Flip wolf
	        }

	        // Collision with player
	        if (playerAlive && boundingBoxCollision(player, wolf)) {
	            long now = System.currentTimeMillis();
	            if (now - lastWolfAttackTime > 1000) {
	                playerHealth--;
	                new Sound("sounds/hurt.wav").start();
	                lastWolfAttackTime = now;

	                if (currentLevel == 1) {
	                    wolf.setAnimation(WWAttack);
	                } else {
	                    wolf.setAnimation(RWAttack);
	                }
	                // Ensure the wolf stays on the ground while attacking
	                int tileX = (int) ((wolf.getX() + wolf.getWidth() / 2) / tmap.getTileWidth());
	                int tileY = 0;

	                for (int y = tmap.getMapHeight() - 1; y >= 0; y--) {
	                    char tileChar = tmap.getTileChar(tileX, y);
	                    if (tileChar == 'x' || tileChar == 'y' || tileChar == 'z') {
	                        tileY = y;
	                        break;
	                    }
	                }
	                wolf.setY((tileY * tmap.getTileHeight()) - wolf.getHeight());
	                wolf.setVelocityX(0); // Stop during attack

	                if (playerHealth <= 0) {
	                    playerAlive = false;	                  
	                    player.setAnimation(dead);	                    
	                    //player.setVelocityX(0);
	                    wolf.setVelocityX(0);
	                    rock.setVelocityX(0);
	                    player.setX(player.getX() - 50);
	                    
	                    new Thread(() -> {
	               	        try {
	               	            Thread.sleep(3000); // death animation for 3 seconds	               	            
	               	            gameState = GameState.GAMEOVER;
	               	            // Stop the background music
	               	         if (gameState == GameState.GAMEOVER && bgMusic != null) {
	               	             bgMusic.stop();
	               	         }
	               	        } catch (InterruptedException ex) {
	               	            ex.printStackTrace();
	               	        }
	               	        player.setAnimation(dead);
            	            new Sound("sounds/death.wav").start();
	               	    }).start();
	                }

	                // Reset walking after attacking
	                new Thread(() -> {
	                    try {
	                        Thread.sleep(600);	                        
	                        if (wolfAliveMap.get(wolf)) {
	                            wolf.setAnimation(currentLevel == 1 ? WWWalk : RWWalk);
	                            wolf.setVelocityX(-0.02f); 
	                        }	                        
	                    } catch (InterruptedException ex) {
	                        ex.printStackTrace();
	                    }
	                }).start();
	            }
	        } else {	        	
	            // Set walk if not attacking
	            if (wolf.getAnimation() != WWAttack && wolf.getAnimation() != RWAttack) {
	                wolf.setAnimation(currentLevel == 1 ? WWWalk : RWWalk);
	                // Ensure wolf is on the ground
	                int tileX = (int) ((wolf.getX() + wolf.getWidth() / 2) / tmap.getTileWidth());
	                int tileY = 0;

	                for (int y = tmap.getMapHeight() - 1; y >= 0; y--) {
	                    char tileChar = tmap.getTileChar(tileX, y);
	                    if (tileChar == 'x' || tileChar == 'y' || tileChar == 'z') {
	                        tileY = y;
	                        break;
	                    }
	                }
	                wolf.setY((tileY * tmap.getTileHeight()) - wolf.getHeight());
	            }
	        }	        

	        // Update wolf
	        wolf.update(elapsed);
	    }
	}
		     
	// check fire tile
	public boolean isFireTile(int x, int y) {
	    if (!tmap.valid(x, y)) return false;
	    return tmap.getTileChar(x, y) == 'f';
	}


}
